"""Full JSON-RPC flow against an isolated Neo4j database, using a synthetic PDF."""
import base64

from backend.server.app import app
from backend.tests.conftest import SyncASGIClient
from backend.tests.test_auth import _rpc, _register_and_login
from backend.tests.test_integration import neo4j_db, neo4j_container  # noqa: F401
from backend.tests.test_llm_foundation import _build_single_page_text_pdf


def test_two_user_pdf_preview_commit_and_evidence(neo4j_db, tmp_path, monkeypatch):
    monkeypatch.setenv("ONTOFORGE_UPLOAD_DIR", str(tmp_path))
    monkeypatch.setenv("ONTOFORGE_SOURCE_DIR", str(tmp_path / "sources"))
    monkeypatch.setenv("ONTOFORGE_LLM_PROVIDER", "disabled")
    client = SyncASGIClient(app)
    alice = _register_and_login(client, "alice")
    bob = _register_and_login(client, "bob")

    def rpc(method, params, user=alice):
        return _rpc(client, method, params, token=user["token"]).json()

    workspace = rpc("createWorkspace", {"name": "API acceptance", "root": "test"})["result"]["workspace"]
    workspace_id = workspace["id"]
    raw = _build_single_page_text_pdf(["The reconfiguration delay is 12.5 ms."])
    upload = rpc("uploadPdf", {"workspace_id": workspace_id, "file_name": "synthetic-regression.pdf",
        "content_base64": base64.b64encode(raw).decode()})["result"]
    params = {"workspace_id": workspace_id, "domain_pack_namespace": "optical", "upload_id": upload["upload_id"]}
    preview = rpc("parsePdfWithDomainPack", params)["result"]
    assert preview["assertion_extraction_method"] == "heuristic"
    assert preview["assertions"]
    params["preview_id"] = preview["preview_id"]
    committed = rpc("commitParsedPdf", params)["result"]
    assert committed["assertions_created"] > 0
    source_params = {"workspace_id": workspace_id, "paper_id": committed["paper_id"]}
    preserved = rpc("getPaperSource", source_params)["result"]
    assert base64.b64decode(preserved["content_base64"]) == raw
    assert rpc("getPaperSource", source_params, user=bob)["error"]["code"] == -32003
    assert rpc("commitParsedPdf", params)["result"]["assertions_created"] == 0
    evidence = rpc("getEvidence", {"workspace_id": workspace_id, "paper_id": committed["paper_id"],
        "metric_name": "optical:reconfiguration_delay"})["result"]
    assert evidence  # actual DB evidence, not a browser fixture
    evidence_id = evidence["evidence"][0]["id"]
    assert evidence["evidence"][0]["verification_status"] == "raw"
    verified = rpc("sspVerifyNode", {"params": {"node_id": evidence_id, "action": "approve", "verified_by": "session"}})
    assert "result" in verified, verified
    reloaded = rpc("getEvidence", {"workspace_id": workspace_id, "paper_id": committed["paper_id"],
        "metric_name": "optical:reconfiguration_delay"})["result"]
    assert reloaded["evidence"][0]["verification_status"] == "verified"
    assert rpc("getPapers", {"workspace_id": workspace_id}, user=bob)["error"]["code"] == -32003
    bob_workspace = rpc("createWorkspace", {"name": "Bob", "root": "test"}, user=bob)["result"]["workspace"]
    foreign = rpc("commitParsedPdf", {**params, "workspace_id": bob_workspace["id"]}, user=bob)
    assert foreign["error"]["code"] == -32003
    assert "error" in _rpc(client, "getPapers", {"workspace_id": workspace_id}).json()
